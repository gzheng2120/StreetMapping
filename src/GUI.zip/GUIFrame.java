import java.io.IOException;

import javax.swing.JFrame;

public class GUIFrame extends JFrame {
	public static void main(String[] args) throws IOException {
		JFrame jframe = new JFrame();
		GUI a = new GUI();
		jframe.add(a);
		
		jframe.setSize(800, 600);
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setVisible(true);
	}

}
